This is a Demo for using and connection RabbitMQ with C#.
I hope you enjoy that.
