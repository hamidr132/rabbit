﻿namespace CommonCode
{
    public enum OperationType
    {
        Add,
        Subtract
    }
}
