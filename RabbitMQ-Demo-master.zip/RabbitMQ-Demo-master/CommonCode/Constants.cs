﻿namespace CommonCode
{
    public static class Constants
    {
        public const string RequestIdHeaderKey = "RequestId";
    }
}
