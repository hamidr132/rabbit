# masstransit-rabbitmq-dotnetcore-implementation
This repository is MassTransit-RabbitMQ basic dotnetcore implementation.
