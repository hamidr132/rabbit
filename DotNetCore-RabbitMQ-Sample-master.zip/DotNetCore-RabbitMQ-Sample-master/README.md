#  .Net Core 2.2 & RabbitMQ Sample

#### RabbitMQ Exchange Types
- Direct
- Fanout
- Topic
- Headers

#### Useful Link

- https://www.rabbitmq.com/

- https://www.rabbitmq.com/dotnet-api-guide.html
- https://www.tutlane.com/tutorial/rabbitmq/rabbitmq-tutorial
- https://www.rabbitmq.com/amqp-0-9-1-quickref.html
